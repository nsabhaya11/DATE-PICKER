//
//  ViewController.swift
//  datepicker
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var dpicker: UIDatePicker!
    @IBOutlet weak var txt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let d = Date();
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        txt.text = frm.string(from: d);
        dpicker.isHidden = true;
    }

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        dpicker.isHidden = false;
        
        return false;
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func dpickeraction(_ sender: AnyObject) {
        
        let d = dpicker.date;
        let frm = DateFormatter();
        frm.dateFormat = "dd-MM-yyyy";
        txt.text = frm.string(from: d);
        dpicker.isHidden = true;
    
    }

}

